
# SECURITY WARNING: keep the secret key used in production secret!
mySECRET_KEY = 'django-insecure---2e%&v=!e247c0ppb17rsxximbik5m(*^i1%7&tne=b5u9gpc'


